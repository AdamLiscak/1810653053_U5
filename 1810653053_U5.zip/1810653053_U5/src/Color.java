

public enum Color {
    SILVER("silver"), BLACK("black"), RED("red"), BLUE("blue"), WHITE("white");
    public String color;

    Color(String color)
    {
        this.color=color;

    }



}
